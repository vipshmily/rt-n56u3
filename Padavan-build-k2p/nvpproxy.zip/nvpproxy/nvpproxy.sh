#!/bin/sh
#edit by goget
nohup /media/st750/run/nvpproxy -port=8888 -proxy=127.0.0.1:1194 > /dev/null 2>&1 &
iptables -I INPUT -p tcp --dport 8888 -j ACCEPT
